import React, { useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import ChatModal from './components/ChatModal';
import HomePage from './pages/HomePage';
import CreateItemPage from './pages/CreateItemPage';
import ItemDetailPage from './pages/ItemDetailPage';
import DropoffPage from './pages/DropoffPage';
import StatsPage from './pages/StatsPage';
import NotFoundPage from './pages/NotFoundPage';

export default function App() {
  const [activeChatItem, setActiveChatItem] = useState(null);
  const [unreadCount, setUnreadCount] = useState(1);

  const handleOpenChat = (item) => {
    setActiveChatItem(item);
  };

  const handleCloseChat = () => {
    setActiveChatItem(null);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-800">
      <Navbar
        unreadCount={unreadCount}
        onOpenInbox={() => {
          // จำลองเปิดแชทของโพสต์บัตรนักศึกษา
          setActiveChatItem({
            id: 3,
            name: "บัตรประจำตัวนักศึกษา (คณะวิทยาการคอมพิวเตอร์)",
            reporter_name: "ปิยะ (ผู้พบของ)",
            reporter_faculty: "คณะวิศวกรรมศาสตร์",
            is_my_post: true,
            status: "searching"
          });
          setUnreadCount(0);
        }}
      />

      <main className="flex-1 flex flex-col">
        <Routes>
          <Route path="/" element={<HomePage onOpenChat={handleOpenChat} />} />
          <Route path="/create" element={<CreateItemPage />} />
          <Route path="/items/:id" element={<ItemDetailPage onOpenChat={handleOpenChat} />} />
          <Route path="/dropoffs" element={<DropoffPage />} />
          <Route path="/stats" element={<StatsPage />} />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </main>

      <Footer />

      {activeChatItem && (
        <ChatModal
          item={activeChatItem}
          onClose={handleCloseChat}
          onItemResolved={() => {
            // refresh
          }}
        />
      )}
    </div>
  );
}
